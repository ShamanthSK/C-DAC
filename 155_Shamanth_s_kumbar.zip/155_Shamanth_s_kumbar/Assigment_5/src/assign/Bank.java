package assign;


class BankAccount{
	
	int acntNo;
	String custoname;
	double balance;
	
	BankAccount(int acntNo,String custoname,double balance){
		
		this.acntNo=acntNo;
		this.custoname=custoname;
		this.balance=balance;
		
	}
	
	
	void display() {
		
		System.out.println("Account Number  :"+acntNo);
		System.out.println("Customer Name : "+custoname);
		System.out.println("Balance : "+balance);
		
	}
	
	
}


class SavingAccount extends BankAccount{
	
	double intrest;
	
	double totalIntrest;
	SavingAccount(int acntNo,String custoname,double balance,double intrest){
		
		super(acntNo,custoname,balance);
		this.intrest=intrest;
		
	}
	
	void calIntrest() {
		
		totalIntrest = balance*(intrest/100);
		
	}
	
	void display() {
		
		System.out.println("Saving Account Details : ");
		super.display();
		System.out.println("Ïntrest Rate : "+totalIntrest);
		
	}
	
}



class CurrentAccount extends BankAccount{
	
	double minBalance;
	
	
	
	CurrentAccount(int acntNo,String custoname,double balance,double minBalance){
		
		super(acntNo,custoname,balance);
		this.minBalance=minBalance;
		
	}
	
	void miniBalance() {
		
		if(balance<minBalance) {
			System.out.println("Minimum Balance is not maintained"+minBalance+" Present balance is : "+balance);
			
		}
		else {
			
			System.out.println("Minimum Balance is maintained : total balance =  "+balance);
			
		}
		
	}
	
	void display() {
		
		System.out.println("Cuurent Account Details : ");
		super.display();
		
	}
	
}


public class Bank {

	
	public static void main(String[] args) {
		
		SavingAccount[] s = new SavingAccount[2];
		
		s[0] = new SavingAccount(10001,"Arya",50000,9);
		
		s[1] = new SavingAccount(10002,"myra",5000,6);
		
		
		CurrentAccount[] c = new CurrentAccount[2];
		
		c[0] = new CurrentAccount(1001010,"Rekha",100000,10000);
		
		c[1] = new CurrentAccount(10001,"Sudha",5000,10000);
		
		for(SavingAccount sav : s) {
			
			sav.calIntrest();
			sav.display();
			
		}
		
		for(CurrentAccount cur : c) {
			
			cur.display();
			cur.miniBalance();
			
		}
		
	}
	
}
