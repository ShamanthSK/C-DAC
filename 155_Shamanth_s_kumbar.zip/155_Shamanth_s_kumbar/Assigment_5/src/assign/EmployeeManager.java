package assign;
import java.util.*;
class Employee{
	
	int empid;
	String empName;
	double salary;
	static String compName = "HPE";
	Employee(int empid,String empName,double salary) {
		
		this.empid=empid;
		this.empName=empName;
		this.salary=salary;
		
	}
	
	void display() {
		
		System.out.println("Employee details :");
		System.out.println("ID : "+empid);
		System.out.println("Name : "+empName);
		
	}
	
	
}

class Manager extends Employee {
	
	String dept;
	int teamSize;

	Manager(int empid,String empName,double salary,String dept,int teamSize) {
		
		super(empid,empName,salary);
		this.dept=dept;
		this.teamSize=teamSize;
		
	}
	
	
	
	void display() {
		super.display();
		System.out.println("Company : "+compName);
		System.out.println("Department : "+dept);
		System.out.println("Team Size : "+teamSize);
		System.out.println("Anunual salary  : "+salary*12+" CTC");
		
	}
	
	
}

public class EmployeeManager {

	public static void main(String[] args) {
		
		Manager m1 = new Manager(101,"Arya",75000,"Deve",12);
		
		Manager m2 = new Manager(102,"sudha",55000,"HR",6);
		
		Manager m3 = new Manager(103,"Myra",60000,"QE",5);
		
		m1.display();
		
		m2.display();
		
		m3.display();
		
	}
	
}
