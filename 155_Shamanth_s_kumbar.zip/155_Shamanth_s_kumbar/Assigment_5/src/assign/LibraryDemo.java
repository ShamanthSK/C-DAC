package assign;


class Book{
	
	int bookId;
	String title;
	String author;
	double price;
	
	
	public Book(int bookId, String title, String author, double price) {
		
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.price = price;
		
	}
	
	void bookDisplay() {
		
		System.out.println("Book ID : "+bookId);
		System.out.println("Title : "+title);
		System.out.println("Author : "+author);
		System.out.println("Price : "+price);
		
	}
	
}


class Library{
	
	String libName;
	String location;
	Book b;
	static int totalBooks=1220;
	
	public Library(String libName, String location, Book b) {
		
		this.libName = libName;
		this.location = location;
		this.b = b;
		
	}
	
	void libraryDisplay() {
		
		System.out.println("Library Details");
		System.out.println("Library name : "+libName);
		System.out.println("Location : "+location);
		System.out.println("Total Books : "+totalBooks);
		b.bookDisplay();
		System.out.println();
		
	}
	
	
}



public class LibraryDemo {

	public static void main(String[] args) {
		
		Book b1 = new Book(10241,"Ätomic Habits","XYZ",500);
		Book b2 = new Book(10122,"We are Together","Siddharth",300);
		Book b3 = new Book(19822,"Nannavalu","Ravi Belagere",450);
		
		Library l1 = new Library("Central library","Banglore",b1);
		Library l2 = new Library("City library","Mysore",b2);
		Library l3 = new Library("Ramanuja Library","Shivamogga",b3);
		
		l1.libraryDisplay();
		l2.libraryDisplay();
		l3.libraryDisplay();
		
		
		
	}
	
}
