package assign;


class Vehicle {
	
	String vehicleNo;
	String brand;
	double price;
	
	
	public Vehicle(String vehicleNo, String brand, double price) {
		
		this.vehicleNo = vehicleNo;
		this.brand = brand;
		this.price = price;
		
	}
	
	void display() {
		
		System.out.println("Vehicle No :  "+vehicleNo);
		System.out.println("brand : " +brand);
		System.out.println("Price : "+price);
	
		
	}
	
}

class car extends Vehicle {
	int numberofdoors;
	String fuelType;
	
	
	public car(String vehicleNo, String brand, double price,int numberofdoors, String fuelType) {
		
		super(vehicleNo,brand,price);
		this.numberofdoors = numberofdoors;
		this.fuelType  = fuelType;
		
	}
	
	double insu;
	
	void carInsurence(){
		
		insu = price*0.08;
		System.out.println("Insureance amount is : "+insu);
		
	}
	
	void carDisplay() {
		
		super.display();
		System.out.println("Final price inlcuding inssurance : "+(price+insu));
		
	}
	
}

class bike extends Vehicle{
	
	int engineCC;
	String helmetincluded;
	
	public bike(String vehicleNo, String brand, double price, int engineCC, String helmetincluded) {
		
		super(vehicleNo, brand, price);
		this.engineCC = engineCC;
		this.helmetincluded = helmetincluded;
		
	}
	
	double insu;

	void bikeInsurence(){
		
		insu = price*0.05;
		System.out.println("Insureance amount is : "+insu);
		
	}
	
	void bikeDisplay() {
		
		super.display();
		System.out.println("Final price inlcuding inssurance : "+(price+insu));
		
	}
	
}

public class VehicleDemo {

	public static void main(String[] args) {
		
		
		car[] c = new car[2];
		
		c[0] = new car("KA14mc3577","BMW", 6000000, 4, "Petrol");
		
		c[1] = new car("KA17mc357","mercedez", 8500000, 4, "Petrol");
		
		bike[] b = new bike[2];
		
		b[0] = new bike("KA1M7605","Honda", 80000, 120, "Yes");
		
		b[1] = new bike("KA14AB1234","Bajaj", 120000, 350, "No");
		
		
		for(bike val : b) {
			
			val.bikeInsurence();
			val.bikeDisplay();
			
		}
		
		
		for(car val : c) {
			
			val.carInsurence();
			val.carDisplay();
			
		}
		
		
		
	}
	
}
