package assign;


class Person{
	
	String name;
	int age;
	
	Person(String name,int age) {
		
		this.name=name;
		this.age=age;
		
	}
	
	void display() {
		
		System.out.println("Name : "+name);
		System.out.println("Age : "+age);
		
	}
	
}

class Employeee extends Person{
	
	int empid;
	double salary;
	
	Employeee (int empid,String name,int age,double salary) {
		
		super(name,age);
		this.empid=empid;
		this.salary=salary;
		
	}
	
	void display() {
	
		System.out.println("ID : "+empid);
		super.display();
		System.out.println("salary  :"+salary);
		
	}
	
}

class Managerr extends Employeee {
	
	String dept;
	int team;
	
	Managerr(int empid,String name,int age,double salary,String dept,int team) {
		
		
		super(empid,name,age,salary);
		this.dept=dept;
		this.team=team;
		
	}
	
	void display() {
		
		System.out.println("Manager details :");
		super.display();
		System.out.println("Department : "+dept);
		System.out.println("Team size : "+team);
		
	}
	
}



public class personEmpMana {

	public static void main(String[] args) {
		
	
	Managerr[] m = new Managerr[3];
	
	m[0] = new Managerr(101,"Arya",22,78000,"Developemnt",10);
	
	m[1] = new Managerr(102,"Rekha",45,68000,"HR",4);

	m[2] = new Managerr(103,"mrya",35,88000,"QE",7);
	
	for(Managerr val : m) {
		
		val.display();
		
	}
	
	}
	
}
