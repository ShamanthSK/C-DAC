package assign4;

public class Electricity {

	int consNo;
	String consName;
	double units;
	
	double bill;
	Electricity(int consNo,String consName,double units){
		
		this.consNo = consNo;
		this.consName = consName;
		this.units = units;
		
	}
	
	void calculateBill() {
		
		if(units>=0 && units<=100) bill = units*2;
		else if(units>=101 && units<=200) bill = 100*2+(units-100)*3;
		else if(units>=201 && units<=300) bill= 100*2+100*3+(units-200)*5;
		else bill=100*2+100*3+100*5+(units-300)*7;
		
	}
	
	void display() {
		
		System.out.println("Consumer Details : ");
		System.out.println("Consumer No : "+consNo);
		System.out.println("units : "+units);
		System.out.println("Bill Amount : "+bill);
		
	}
	
	
}
