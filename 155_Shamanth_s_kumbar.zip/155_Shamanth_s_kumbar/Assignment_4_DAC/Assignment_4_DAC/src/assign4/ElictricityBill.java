package assign4;

public class ElictricityBill {

	public static void main(String[] args) {
		
		Electricity e1 = new Electricity(1001,"Arya",250);
		
		Electricity e2 = new Electricity(1002,"Suma",95);
		
		Electricity e3 = new Electricity(1003,"Rekha",150);
		
		Electricity e4 = new Electricity(1004,"Neha",320);
		
		Electricity e5 = new Electricity(1005,"pala",220);
		
		
		e1.calculateBill();
		e1.display();
		
		e2.calculateBill();
		e2.display();
		
		e3.calculateBill();
		e3.display();
		
		e4.calculateBill();
		e4.display();
		
		e5.calculateBill();
		e5.display();
		
	
	}
	
}
