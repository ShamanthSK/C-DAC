package assign8;
import java.util.*;
import java.io.*;


public class ArrayListObjectMain {

	public static void main(String[] args) throws Exception{
		
		Scanner sc = new Scanner(System.in);
		ArrayList<Book> a;
		ArrayListOjectManagement am = new ArrayListOjectManagement();
		
		while(true) {
			
			System.out.println("--------------------------------------------");
			System.out.println("1. Create File ");
			System.out.println("2. Read objects from file");
			System.out.println("3. Display Books");
			System.out.println("4. Search Book");
			System.out.println("5. Update Book Price");
			System.out.println("6. Delete Book");
			System.out.println("7. Display Books Above ₹500");
			System.out.println("8. Find Most Expensive Book");
			System.out.println("9. Sort Books by Price");
			System.out.println("10. Display Book Count");
			System.out.println("11. Calculate Average Price");
			System.out.println("12. Save Updated Data");
			System.out.println("13. Exit");
			
			System.out.print("Enter choice : ");
			int ch = sc.nextInt();
			
			switch(ch) {
			
			case 1 : am.createObjectFile();
				     break;
				     
			case 2 : a = am.readObjectFile();
					 break;
					 
			case 3 : am.displayBooks();
					 break;
					 
			case 4 : am.searchBook();
					 break;
					 
			case 5 : a = am.updateBookPrice();
					 break;
					 
			case 6 : a = am.deleteBook();
					 break;
					 
			case 7 : am.displayBooksAboveRupees();
					 break;
					 
			case 8 : am.findMostExpensiveBook();
					 break;
					 
			case 9 : am.sortBooks();
					 break;
					 
			case 10 : am.displayBookCount();
					  break;
					  
			case 11 : am.calculateAvgPrice();
					  break;
					  
			case 12 : am.saveDataBacktoFile();
					  break;
					 
			case 13 : System.out.println("Exiting from program...!");
					  System.exit(0);
					  
			default : System.out.println("Invalid choice....!");
					  
			}
			
			
		}
		
	}
	
}