package assign8;
import java.util.*;
import java.io.*;

public class ArrayListOjectManagement {

	Scanner sc = new Scanner(System.in);
	ArrayList<Book> al = new ArrayList<>();
	
	public void createObjectFile() throws IOException {
		
		FileReader fr = new FileReader("Books.csv");
		BufferedReader br = new BufferedReader(fr);
		
		FileOutputStream fos = new FileOutputStream("ProblemObj4.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		String str;
		
		
		while((str=br.readLine())!= null) {
			
			String[] data = str.split(",");
			Book b = new Book(Integer.parseInt(data[0]),data[1],data[2],Double.parseDouble(data[3]));
			oos.writeObject(b);
			
		}
		
		
//		Book b1 = new Book(1001,"ramayan","Valmiki",520);
//		Book b2 = new Book(1002,"we are togther","Siddharth",450);
//		Book b3 = new Book(1003,"Mouna","Ravi",680);
		
//		oos.writeObject(b1);
//		oos.writeObject(b2);
//		oos.writeObject(b3);
		
		System.out.println("File write is over");
		
		fos.close();
		oos.close();	
		
	}
	
	public ArrayList<Book> readObjectFile() throws IOException, ClassNotFoundException {
		
		al.clear();
		
		FileInputStream fis = new FileInputStream("ProblemObj4.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Book b;
		try {
			while((b=(Book)ois.readObject())!=null) {
				
				al.add(b);
				b.displayBooks();
				
		}
		}catch(Exception e) {
			
			System.out.println();
			
		}
		
		return al;
	}

	public void displayBooks() {
		
		System.out.println("Book Details");
		for(Book obj : al) {
			
			obj.displayBooks();
			
		}
		
	}

	public void searchBook() {
		
		System.out.println("Enter Book Id to search");
		int id = sc.nextInt();
		int check=0;
		for(Book obj : al) {
			
			if(obj.bookid==id) {
				
				System.out.println("Book found");
				check=1;
			}
			
		}
		if(check==0) System.out.println("Book not found");
		
	}

	public ArrayList<Book> updateBookPrice() {
		
		System.out.println("Enter book Id to update price");
		int id = sc.nextInt();
		System.out.println("Enter new price");
		double amt = sc.nextDouble();
		int check=0;
		for(Book obj : al) {
			
			if(obj.bookid==id) {
				
				obj.price=amt;
				check=1;
				System.out.println("Book is updated");
			}
			
		}
		if(check==0) System.out.println("Book not found!");
		
		
		return al;
		
	}

	public ArrayList<Book> deleteBook() {
		
		System.out.println("Enter book Id to delete");
		int id = sc.nextInt();
		int count=0;
		int flag=0;
		for(Book obj : al) {
			
			if(obj.bookid==id) {
				
				al.remove(count);
				System.out.println("Book removed");
				flag=1;
				break;
				
			}
			count++;
			
		}
		if(flag==0) System.out.println("Book is not found and is not removed");
		
		return al;
		
	}

	public void displayBooksAboveRupees() {
		
		System.out.println("Books above 500-rupees");
		for(Book obj : al) {
			
			if(obj.price>500) {
				
				obj.displayBooks();
				
			}
			
		}
		
	}

	public void findMostExpensiveBook() {
		
		System.out.println("The most expensive book ");
		Book b1 = new Book(0,null,null,0);
		for(Book obj : al) {
			
			if(obj.price>b1.price) {
				
				b1=obj;
				
			}
			
		}
		
		b1.displayBooks();
	}

	public void displayBookCount() {
		
		int count=0;
		for(Book obj : al) {
			
			count++;
			
		}
		System.out.println("Total number of books : "+count);
		
	}

	public void calculateAvgPrice() {
		
		double sum=0,count=0;
		for(Book obj : al) {
			
			sum+=obj.price;
			count++;
			
		}
		System.out.println("Average price is : "+(sum/count));
		
	}

	public void saveDataBacktoFile() throws IOException {
		
		FileOutputStream fos = new FileOutputStream("ProblemObj4.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		for(Book obj : al) {
			
			oos.writeObject(obj);
			
		}
		System.out.println("Saved updated data to file");
		
//		return al;
		fos.close();
		oos.close();
		
	}

	public void sortBooks() {
		
		sortByPrice sp = new sortByPrice();
		Collections.sort(al,sp);
		System.out.println("Sorting is done");
		
	}
	
	
}