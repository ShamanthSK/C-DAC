package assign8;

public class ArrayListReadObject {

}
