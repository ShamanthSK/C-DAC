package assign8;

public class ArrayListWriteObject {

}
