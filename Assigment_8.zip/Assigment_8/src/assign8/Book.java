package assign8;
import java.util.*;
import java.io.Serializable;

public class Book implements Serializable{
	
	int bookid;
	String title;
	String author;
	double price;
	
	public Book(int bookid, String title, String author, double price) {
	
		this.bookid = bookid;
		this.title = title;
		this.author = author;
		this.price = price;
	}


	void displayBooks() {
		
		System.out.println("id : "+bookid+" ,Title : "+title+" ,author : "+author+" ,Price : "+price);
		
	}
	

}
