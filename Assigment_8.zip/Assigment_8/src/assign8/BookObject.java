package assign8;
import java.util.*;
import java.io.Serializable;

public class BookObject implements Serializable{
	
	int bookid;
	String title;
	String author;
	double price;
	
	public BookObject() {
		
		System.out.println("Enter Book details (BookId=-1 means exit)");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter BookId,Title,Author,Price of book");
		this.bookid = sc.nextInt();
		this.title = sc.next();
		this.author = sc.next();
		this.price = sc.nextDouble();
		
	}
	
	
	void displayBooks() {
		
		System.out.println("Book Detail");
		System.out.println("id : "+bookid+" ,Title : "+title+" ,author : "+author+" ,Price : "+price);
		
	}
	

}
