package assign8;
import java.io.*;

public class CharacterBasedFileReader {

	public static void main(String[] args) throws IOException {
		
		FileReader fr = new FileReader("probelm1.txt");
		
		int ch;
		int upcnt=0,lcnt=0,digits=0,spcl=0,spaces=0;
		System.out.println("Data Read from File:");
		
		while((ch=fr.read())!=-1) {
			
			if(ch==' ') spaces++;
			else if(Character.isUpperCase((char)ch)) upcnt++;
			else if(Character.isLowerCase((char)ch)) lcnt++;
			else if(Character.isDigit((char)ch)) digits++;
			else spcl++;
			System.out.print((char)ch);
			
		}
		System.out.println();
		
		System.out.println("Uppercase Characters:  : "+upcnt);
		System.out.println("Lowercase Characters : "+lcnt);
		System.out.println("Digits : "+digits);
		System.out.println("Special Characters : "+spcl);
		System.out.println("Spaces : "+spaces);
				
		
	}
	
}
