package assign8;
import java.io.*;
import java.util.*;


public class CharacterBasedFileWrite {

	public static void main(String[] args) throws IOException{
		
		Scanner sc = new Scanner(System.in);
		
		FileWriter fw = new FileWriter("probelm1.txt");
		
		System.out.println("Enter a string");
		String str = sc.nextLine();
		
		fw.write(str);
		System.out.println("File write is done!");
		fw.close();
		
	}
	
}
