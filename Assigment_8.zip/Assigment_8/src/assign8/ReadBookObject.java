package assign8;
import java.io.*;

public class ReadBookObject {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		FileInputStream fis = new FileInputStream("problem3.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		BookObject b;
		try {
			while((b=(BookObject)ois.readObject())!=null) {
				
				b.displayBooks();
				if(b.price>500) {
					
					double dis = b.price-b.price*0.1;
					System.out.println("Price is greater 500 so 10% disacount final price : "+dis);
					
				}
				
			}	
		}catch(EOFException e) {
			
			System.out.println();
			
		}
		}
		
	}
	

