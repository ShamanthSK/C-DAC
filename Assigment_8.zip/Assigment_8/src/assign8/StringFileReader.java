package assign8;
import java.io.*;

public class StringFileReader {

	
	public static void main(String[] args) throws IOException {
		
		FileReader fr = new FileReader("problem2.txt");
		BufferedReader br = new BufferedReader(fr);
		
		String str = br.readLine();
		
		String[] words = str.split(" ");
//		
//		int wordCount = words.length;
		
//		Words,vowels,Consonants count
		int vowels=0,cons=0,wordcnt=0;
		for(int i=0,j=str.length()-1;i<str.length();i++) {
			
			 char c = Character.toLowerCase(str.charAt(i));
			if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u') 
				vowels++;
			else if(c ==' ') {
				
				wordcnt++;
			}
			else {
				
				cons++;
				
			}
			
			
		}
		
		//Longest sub string	
		String longestStr="";
		
		for(String w : words) {
			
			if(w.length()>longestStr.length())
				longestStr = w;
			
		}
		
//		Reversing - Method I
				
//		char[] arr = str.toCharArray();
//		int i=0,j=str.length()-1;
//		
//		while(i<j) {
//			
//			char temp = arr[i];
//			arr[i]=arr[j];
//			arr[j]=temp;
//			i++;
//			j--;
//			
//		}
		
//		Reversing - Method II
		
		String reverse = new StringBuilder(str).reverse().toString();
		
//		Converting to upper case
		String upper = str.toUpperCase();
		
		
		System.out.println("Words count : "+(wordcnt+1));
		System.out.println("Vowels : "+vowels);
		System.out.println("Consonants : "+cons);
		System.out.println("Longest String  :"+longestStr);
		System.out.println("Reversed:");
		System.out.println(reverse);
		System.out.println("Upper Case : ");
		System.out.println(upper);
		
	}
	
}
