package assign8;
import java.util.*;
import java.io.*;

public class StringFileWrite {

	public static void main(String[] args) throws IOException {
		
		Scanner sc = new Scanner(System.in);
		
		FileWriter fw = new FileWriter("problem2.txt");
		
		System.out.println("Enter the string");
		String str = sc.nextLine();
		
		fw.write(str);
		
		System.out.println("File write over");
		fw.close();
		
	}
	
}
