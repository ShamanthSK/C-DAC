package assign8;
import java.util.*;
import java.io.*;

public class WriteBookObject {

	public static void main(String[] args) throws IOException {
		
//		Book b1 = new Book(1001,"ramayan","Valmiki",520);
//		Book b2 = new Book(1002,"we are togther","Siddharth",450);
//		Book b3 = new Book(1003,"Mouna","Ravi",680);
		
		
		
		FileOutputStream fos = new FileOutputStream("problem3.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		while(true) {
			
			BookObject b = new BookObject();
			if(b.bookid == -1) break;
			oos.writeObject(b);
			
			
		}
		
//		oos.writeObject(b1);
//		oos.writeObject(b2);
//		oos.writeObject(b3);
		
		System.out.println("Objects File write is over");
		fos.close();
		oos.close();
		
	}
	
}
