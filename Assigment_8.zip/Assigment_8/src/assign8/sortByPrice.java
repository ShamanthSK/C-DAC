package assign8;
import java.util.*;

public class sortByPrice implements Comparator<Book> {

	@Override
	public int compare(Book b1,Book b2) {
	
		if(b1.price>b2.price)
			return 1;
		else 
			return -1;
	
	}

}
