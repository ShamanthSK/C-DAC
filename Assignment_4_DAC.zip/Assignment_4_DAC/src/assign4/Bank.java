package assign4;

public class Bank {

	int actNum;
	String customerName;
	double balance;
	
	double intrest;
	Bank(int actNum,String customerName,double balance) {
		
		this.actNum= actNum;
		this.customerName=customerName;
		this.balance = balance;
		
	}
	
	void checkBalance() {
		
		System.out.println("Balance Amount : "+balance);
		
	}
	
	
	void calculateIntrest() {
		
		if(balance>=100000) intrest = balance*0.07;
		else if(balance<100000 && balance>=50000) intrest = balance*0.06;
		else intrest = balance*0.05;
		
	}
	
	void display() {
		
		System.out.println("Account Details : ");
		System.out.println("Account Number : "+actNum);
		System.out.println("Name : "+customerName);
		System.out.println("Balance : "+balance);
		System.out.println("Intrest : "+intrest);
		
		
		
	}
	
}
