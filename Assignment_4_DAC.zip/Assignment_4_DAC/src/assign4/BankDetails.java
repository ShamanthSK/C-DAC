package assign4;

public class BankDetails {

	public static void main(String[] args) {
		
		Bank b1 = new Bank(10001,"Arya",70000);
		
		Bank b2 = new Bank(10002,"sumna",110000);

		Bank b3 = new Bank(10003,"Sudha",40000);

		
		b1.checkBalance();
		b1.calculateIntrest();
		b1.display();
		
		b2.checkBalance();
		b2.calculateIntrest();
		b2.display();
		
		b3.checkBalance();
		b3.calculateIntrest();
		b3.display();
		
		
		
	}
	
}
