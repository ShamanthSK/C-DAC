package assign4;

public class Employee {

	int id;
	String name;
	float salary;
	
	void read(int eid,String n,float sal) {
		
		id=eid;
		name=n;
		salary = sal;
		
	}
	
	void display() {
		
		System.out.println("Employee details");
		System.out.println("ID : "+id);
		System.out.println("name : "+name);
		System.out.println("Salary : "+salary);
		
	}
	
	void calculateBonous() {
		
		if(salary>=50000) System.out.println(name + " has Bonus of "+(salary*0.1));
		else System.out.println(name+" has Bonus of "+(salary*0.05));

	}
	
	
}
