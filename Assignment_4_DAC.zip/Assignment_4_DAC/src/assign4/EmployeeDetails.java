package assign4;

public class EmployeeDetails {

	public static void main(String[] args) {
		
		Employee e1 = new Employee();
		e1.read(101, "Arya", 65000);
		
		Employee e2 = new Employee();
		e2.read(102, "sumna", 45000);
		
		Employee e3 = new Employee();
		e3.read(103, "ram", 30000);
		
		Employee e4 = new Employee();
		e4.read(141, "sudha", 70000);
		
		
		e1.display();
		e1.calculateBonous();
		
		e2.display();
		e2.calculateBonous();
		
		e3.display();
		e3.calculateBonous();
		
		e4.display();
		e4.calculateBonous();
		
		
		
	}
	
}
