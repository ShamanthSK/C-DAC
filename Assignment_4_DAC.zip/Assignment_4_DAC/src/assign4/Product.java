package assign4;

public class Product {

	int pid;
	String pname;
	double price;
	int qua;
	
	double total;
	double dis;
	Product(int pid,String pname,double price,int qua) {
		
		this.pid=pid;
		this.pname=pname;
		this.price=price;
		this.qua=qua;
		
	}
	
	void calCulateBill() {
		
		total = price*qua;
		if(total>10000) dis = total*0.1;
		else dis = 0;
			
	}
	
	void display() {
		
		System.out.println("Product Details : ");
		System.out.println("ID : "+pid);
		System.out.println("Name : "+pname);
		System.out.println("Price : "+price);
		System.out.println("quantity : "+qua);
		System.out.println("Total Amount : "+total);
		System.out.println("Discount amount : "+dis);
		System.out.println("Final Amount : "+(total-dis));
		
	}
	
}
