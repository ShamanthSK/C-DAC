package assign4;

public class ProductDetails {

	public static void main(String[] args) {
		
		Product p1 = new Product(101,"Laptop",50000,2);
		
		Product p2 = new Product(102,"Mouse",400,10);
		
		Product p3 = new Product(103,"keyBoard",800,5);
		
		p1.calCulateBill();
		p1.display();
		
		p2.calCulateBill();
		p2.display();
		
		
		p3.calCulateBill();
		p3.display();
		
	}
	
}
