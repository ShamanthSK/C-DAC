package assign4;

public class Student {

	    int rolno;
	    String name;
	    int marks;
	    
	    void display() {
	        System.out.println("name : "+name);
	        System.out.println("Reg no : "+rolno);
	        System.out.println("Marks : "+marks);
	    }

	    void calculateGrade() {
	        if(marks>=90) System.out.println("Grade : A");
	        if(marks>=75 && marks<90) System.out.println("Grade : B");
	        if(marks>=60 && marks<75) System.out.println("Grade : C");
	        if(marks<60) System.out.println("Grade : D");
	    }

	}




