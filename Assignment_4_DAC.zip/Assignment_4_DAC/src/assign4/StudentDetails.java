package assign4;

public class StudentDetails {

	public static void main(String[] args) {
		
		Student s1 = new Student();
		s1.name="Arya";
		s1.rolno=101;
		s1.marks=95;
		
		Student s2 = new Student();
		s2.name="Suman";
		s2.rolno=102;
		s2.marks=80;
		
		
		Student s3 = new Student();
		s3.name="ram";
		s3.rolno=103;
		s3.marks=90;
		
		s1.display();
		s1.calculateGrade();
		
		s2.display();
		s2.calculateGrade();
		
		s3.display();
		s3.calculateGrade();
		
	}
	
}

