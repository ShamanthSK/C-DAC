package Assign_6;
import java.util.*;


abstract class BankAccount {
	
	int acntNo;
	String custoName;
	double balance;
	
	public BankAccount(int acntNo, String custoName, double balance) {
		
		this.acntNo = acntNo;
		this.custoName = custoName;
		this.balance = balance;
		
	}
	
	public void deposit(double amt) {
		
		balance+=amt;
		System.out.println("Deposit amount is : "+amt);
		
	}
	
	public void displayAccount() {
		
		System.out.println("Account number  :"+acntNo);
		System.out.println("customer name : "+custoName);
		System.out.println("Balance amount : "+balance);
		
	}
	
	abstract void calculateWithdrawLimit();
	
}


class SavingAccount extends BankAccount {

	
	double withdrawalPercent;
	
	public SavingAccount(int acntNo, String custoName, double balance,double withdrawalPercent) {
		super(acntNo, custoName, balance);
		this.withdrawalPercent=withdrawalPercent;
	}
	
	double limit;
   @Override
	public void calculateWithdrawLimit() {
		
		limit = balance*(withdrawalPercent/100);
		if(limit>balance) {
			
			System.out.println("Withdrawal percentage is more than balance");
			
		}
		else {
		System.out.println("Withdrawal limit is : "+limit);
	   
	}
   }
   
   public void displaySavingsAccount() {
	   
	   System.out.println("Savings Account Details");
	   super.displayAccount();
	   System.out.println("Withdrawal limit is : "+limit);
	   
   }
		
}


class CurrentAccount extends BankAccount {
	
	double overdraftFacility;
	
	public CurrentAccount(int acntNo, String custoName, double balance,double overdraftFacility) {
		
		super(acntNo, custoName, balance);
		this.overdraftFacility=overdraftFacility;
		
	}
	
	@Override
	public void calculateWithdrawLimit() {
		
		System.out.println("Overdraft Facility limit is : "+(balance+overdraftFacility));
	   
	}
	
	public void displayCuurentAccount() {
		
		System.out.println("Current Account Details");
		super.displayAccount();
		
	}
	
}

public class BankingWihdrawal {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Account number : ");
		int acnt = sc.nextInt();
		
		System.out.println("Enter the customer name : ");
		String name = sc.next();
		
		System.out.println("Enter type of Bank(Savings or Current)");
		String type = sc.next();
		
		if(type.equals("savings")) {
			
			System.out.println("Enter the amount to be deposited");
			double deposit = sc.nextDouble();
			
			SavingAccount s = new SavingAccount(acnt,name,50000,40);
			s.deposit(deposit);
			
			s.calculateWithdrawLimit();
			s.displaySavingsAccount();
			
		}
		

		else if(type.equals("current")) {
			
			System.out.println("Enter the amount to be deposited");
			double deposit = sc.nextDouble();
			
			CurrentAccount c = new CurrentAccount(acnt,name,100000,25000);
			c.deposit(deposit);
			
			c.calculateWithdrawLimit();
			c.displayCuurentAccount();
			
		}
		
	}
	
}
