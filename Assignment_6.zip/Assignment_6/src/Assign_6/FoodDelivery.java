package Assign_6;
import java.util.*;


class FoodOrder{
	
	double foodPrice;
	
	
	
	public void calculateBill(double foodPrice) {
		
		System.out.println("Total Bill for single item: "+foodPrice);
		
	}
	
	public void calculateBill(double foodPrice, int quantity) {
		
		System.out.println("Total Bill with quatity: "+foodPrice*quantity);
		
	}
	
	public void calculateBill(double foodPrice, int quantity, double deliveryCharge) {
		
		double res = foodPrice*quantity+deliveryCharge;
		System.out.println("Total Bill including delivery charges : "+res);
		
	}
}


public class FoodDelivery {
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Food Price:  ");
		double price = sc.nextDouble();
		
		System.out.println("Enter Food Quantity:  ");
		int qua = sc.nextInt();
		
		
		
		FoodOrder f1 = new FoodOrder();
		f1.calculateBill(price);
		
		FoodOrder f2 = new FoodOrder();
		f2.calculateBill(price, qua);
		
		FoodOrder f3 = new FoodOrder();
		f3.calculateBill(price, qua, 70.0);
		
		
		
		
	}
	
	
	
}
