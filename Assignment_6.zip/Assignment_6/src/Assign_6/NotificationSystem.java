package Assign_6;
import java.util.*;

interface Notification {
	
	void sendNotification(String message);
	void ShowStatus();
	
}

class EmailNotification implements Notification {
	
	String emailId;
	String subject;
	String msg;
	
	public EmailNotification(String emailId, String subject) {

		this.emailId = emailId;
		this.subject = subject;
	
	}
	

	
	public void sendNotification(String message) {
		
		msg=message;
		
	}
	
	public void displayEmail() {
		
		System.out.println("------Email Notification-----");
		System.out.println("Email ID : "+emailId);
		System.out.println("Subject : "+subject);
		System.out.println(msg);
		
	}
	

	public void ShowStatus() {
		
		System.out.println("Status : Email Delivered");
		
	}

	
}


class SMSNotification implements Notification {
	
	long mobileNo;
	String provider;
	String msg;
	
	public SMSNotification(long mobileNo, String provider) {

		this.mobileNo = mobileNo;
		this.provider = provider;
	
		
	}
	
	
	public void sendNotification(String message) {
		
		msg = message;
		
	}
	
	public void displaySMS() {
		
		System.out.println("------SMS Notification-----");
		System.out.println("Mobile Number : "+mobileNo);
		System.out.println("Provider : "+provider);
		System.out.println(msg);
		
	}
	
	
	
	public void ShowStatus() {
		
		System.out.println("Status : SMS Delivered");
		
	}
	
	
}


class PushNotification implements Notification {
	
	int deviceId;
	String name;
	String msg;
	
	public PushNotification(int deviceId, String name) {

		this.deviceId = deviceId;
		this.name = name;
		
	}
	
	
	public void sendNotification(String message) {
		
		msg = message;
		
	}
	
	public void displaySMS() {
		
		System.out.println("------Push Notification-----");
		System.out.println("Device ID : "+deviceId);
		System.out.println("App : "+name);
		System.out.println(msg);
		
	}
	
	
	
	public void ShowStatus() {
		
		System.out.println("Status : Notification Delivered");
		
	}
	
}

public class NotificationSystem {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the mode Message (email/sms/push)");
		String mode = sc.next();
		
		if(mode.equals("email")) {
			
			System.out.println("Enter Email ID : ");
			String email = sc.next();
			sc.nextLine();
			
			System.out.println("Enter the Subject : ");
			String sub = sc.nextLine();
			
			System.out.println("Enter the message : ");
			String msg = sc.nextLine();
			
			EmailNotification e = new EmailNotification(email,sub);
			e.sendNotification(msg);
			e.displayEmail();
			e.ShowStatus();
			
		}
		
		else if(mode.equals("sms")) {
			
			System.out.println("Enter Mobile No : ");
			long mobile = sc.nextLong();
			sc.nextLine();
			
			System.out.println("Enter N/w Provider : ");
			String prov = sc.nextLine();
			
			System.out.println("Enter the message : ");
			String msg = sc.nextLine();
			
			SMSNotification s = new SMSNotification(mobile,prov);
			s.sendNotification(msg);
			s.displaySMS();
			s.ShowStatus();
			
		}
		
	   if(mode.equals("push")) {
			
			System.out.println("Enter Device ID : ");
			int id = sc.nextInt();
			sc.nextLine();
			
			System.out.println("Enter the App name : ");
			String app = sc.nextLine();
			
			System.out.println("Enter the message : ");
			String msg = sc.nextLine();
			
			PushNotification p = new PushNotification(id,app);
			p.sendNotification(msg);
			p.displaySMS();
			p.ShowStatus();
			
		}
		
		
	}
	
}
