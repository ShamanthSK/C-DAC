package Assign_6;
import java.util.*;


class TravelSystem{
	
	int bookingID;
	String passengerName; 
	String source;
	String destination; 
	double distance;
	
	public TravelSystem(int bookingID, String passengerName, String source, String destination, double distance) {
		
		this.bookingID = bookingID;
		this.passengerName = passengerName;
		this.source = source;
		this.destination = destination;
		this.distance = distance;
		
	} 
	
	void displayTravel() {
		
		System.out.println("Passenger Details");
		System.out.println("Booking ID : "+bookingID);
		System.out.println("Name : "+passengerName);
		System.out.println("Source : "+source);
		System.out.println("Destination : "+destination);
		System.out.println("Total distance : "+distance);
		
	}
	
	public double calculateFare() {
		
		System.out.println("Calculating the trip fare");
		return 0;
		
	}

	
}


class Bus extends TravelSystem{
	
	String busType;
	int seatNo;
	
	public Bus(int bookingID, String passengerName, String source, String destination, double distance, String busType,
			int seatNo) {
		
		super(bookingID, passengerName, source, destination, distance);
		this.busType = busType;
		this.seatNo = seatNo;
		
	}
	
	double fare;
	@Override
	public double calculateFare() {
		
		if(busType.equals("Non-AC")) {
			
			fare = distance*1.5;
			return fare;
			
		}else if(busType.equals("AC")) {
			
			fare = distance*2.3;
			return fare;
			
		}else {
			fare = distance*2.6;
			return fare;
			
		}
		
	}
	
	void displayBus() {
		
		super.displayTravel();
		System.out.println("Bus Type : "+busType);
		System.out.println("Seat Number : "+seatNo);
		System.out.println("Total Fare  :"+fare);
		
	}
	
	
}


class Train extends TravelSystem{
	
	int trainNumber ;
	String coachType;
	
	public Train(int bookingID, String passengerName, String source, String destination, double distance,
			int trainNumber, String coachType) {
		
		super(bookingID, passengerName, source, destination, distance);
		this.trainNumber = trainNumber;
		this.coachType = coachType;
	
		
	}

	
	double fare;
	@Override
	public double calculateFare() {
		
		if(coachType.equals("general")) {
			
			fare = distance*0.5;
			return fare;
			
		}else if(coachType.equals("sleeper")) {
			
			fare = distance*1.3;
			return fare;
			
		}else {
			fare = distance*2.1;
			return fare;
			
		}
		
	}
	
	void displayTrain() {
		
		super.displayTravel();
		System.out.println("Train Number : "+trainNumber);
		System.out.println("coachType: "+coachType);
		System.out.println("Total Fare  :"+fare);
		
	}
	
	
}

public class TravelBooking {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Passenger details");
		System.out.print("Name : ");
		String name = sc.next();
		System.out.println();
		
		System.out.print("Source : ");
		String source = sc.next();
		System.out.println();

		System.out.print("Destination : ");
		String dest = sc.next();
		System.out.println();

		System.out.print("Distance : ");
		double dist = sc.nextDouble();
		System.out.println();

		System.out.print("Enter Mode of transportation : ");
		String mode = sc.next();
		
		if(mode.equals("bus")) {
			
			System.out.print("Enter the bus Type : ");
			String type = sc.next();
			System.out.println();
			
			System.out.print("Enter the seat-no : ");
			int sno = sc.nextInt();
			System.out.println();
			
			Bus b = new Bus(1000020,name,source,dest,dist,type,sno);
			
			double res = b.calculateFare();
			System.out.println("Total fare is : "+res);
			
			b.displayBus();
		}
		
		else if(mode.equals("train")) {
			
			System.out.print("Enter the Train number : ");
			int tno = sc.nextInt();
			System.out.println();
			
			System.out.print("Enter the Coach type : ");
			String type = sc.next();
			System.out.println();
			
			Train t = new Train(195566,name,source,dest,dist,tno,type);
			
			double res = t.calculateFare();
			System.out.println("Total fare is : "+res);
			
			t.displayTrain();
		}
		
		else {
			
			System.out.println("Enter valid tansportation mode");
			
			
		}
		
		
	}
	
}
