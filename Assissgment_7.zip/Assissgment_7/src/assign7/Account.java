package assign7;

public class Account {

	int acntNo;
	String name;
	double balance;
	double withdrawAmt;
	
	public Account(int acntNo, String name, double balance,double withdrawAmt) {

		this.acntNo = acntNo;
		this.name = name;
		this.balance = balance;
		this.withdrawAmt=withdrawAmt;
	}
	
	public void withdraw() throws Exception {
		
		if(withdrawAmt<balance && withdrawAmt>0) {
			
			System.out.println("Withdrawal is valid");
			
		}
		else  {
			
			throw new Exception("Withdrawal Amount is invalid try again!");
			
		}
		
	}
	
	public void display() {
		
		System.out.println("Account details");
		System.out.println("Account number : "+acntNo);
		System.out.println("Name : "+name);
		System.out.println("Balance : "+balance);
		System.out.println("Withdraw amount : "+withdrawAmt);
		
	}
	
}
