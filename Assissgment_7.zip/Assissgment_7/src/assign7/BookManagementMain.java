package assign7;
import java.util.*;

public class BookManagementMain {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		BookManagementSystem bm = new BookManagementSystem();
		 ArrayList<Book> a ;
		while(true) {
			
			System.out.println("1. Add Book");
			System.out.println("2. Display books");
			System.out.println("3. Search Book by ID");
			System.out.println("4. Update Book");
			System.out.println("5. Delete Book");
			System.out.println("6. Exit");
			
			System.out.println("Enter your choice : ");
			int ch = sc.nextInt();
			
			switch(ch) {
			
			case 1 : a = bm.addBooks();
					 break;
					 
			case 2 : bm.displayAllBooks();
					 break;
					 
			case 3 : bm.searchById();
					 break;
			
			case 4 : bm.updateBook();
					 break;
			
			case 5 : bm.DeleteBook();
					 break;
			
			case 6 : System.out.println("Program exiting...!");
					 System.exit(0);
					 
			default : System.out.println("Enter valid choice");
			
			}
		}
		
	}
	
}