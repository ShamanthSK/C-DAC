package assign7;
import java.util.*;

public class ExceptionAgeValidation {
		
	public static void checkAge(int age) throws InvalidAge{
		
		if(age<18) {
			
			throw new InvalidAge("Age is under 18 ,not eligible to register for Event");
			
		}
		else {
			
			System.out.println("Age is valid and eligible to regsiter for Event");
			
		}
	}
	
}
