package assign7;

public class ExceptionBankWithdrawalmain {

	public static void main(String[] args) {
		
		Account a = new Account(4241541,"Arya",100000,10000);
		
		try {
			a.withdraw();
			
		}catch(Exception e) {
			
			System.out.println(e.getMessage());
			
		}
		finally {
			
			a.display();
			System.out.println("Final statement is executed");
			
		}
		
	}
	
}
