package assign7;

public class InvalidAge extends Exception{

	String msg=null;
	
	InvalidAge(String msg) {
		
		super(msg);
		
	}
	
}
