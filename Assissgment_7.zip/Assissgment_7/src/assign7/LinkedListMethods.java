package assign7;
import java.util.*;
import java.util.LinkedList;

public class LinkedListMethods {

	LinkedList<String> ll = new LinkedList<>();
	Scanner sc = new Scanner(System.in);
	
	public LinkedList<String> addAtBeginning() {
		
		System.out.println("Enter passanger name to add :");
		String name = sc.next();
		ll.addFirst(name);
		return ll;
		
	}

	public LinkedList<String> addAtLast() {
		
		System.out.println("Enter passanger name to add :");
		String name = sc.next();
		ll.addLast(name);
		return ll;
		
	}

	public void removeAtBeginning() {
		
		String name = ll.removeFirst();
		System.out.println("passenger "+ name +" is removed");
		
	}

	public void removeAtLast() {
		
		String name = ll.removeLast();
		System.out.println("passenger "+ name +" is removed");
		
	}

	public void searchPassenger() {
		
		System.out.println("Enter passenger name to search");
		String name = sc.next();
		
		if(ll.contains(name)) {
			System.out.println("Passenger is found");
			
		}
		else {
			
			System.out.println("Passenger not found");
		}
		
	}

	public void displayPassenger() {
		
		System.out.println("Passenger details ");
		for(String n : ll) {
			
			System.out.println(n);
			
		}
		
	}


}
