package assign7;
import java.util.*;

public class StackBrowserHistoryManagement {


	Scanner sc = new Scanner(System.in);
	Stack<String> s = new Stack<>();
	
	public Stack<String> visitNewPage() {
		
		System.out.println("Enter new page you want to visit");
		String page = sc.next();
		s.push(page);
		System.out.println("New page is added");
		return s;
	}

	public void goBack() {
		
		if(s.isEmpty()) {
			
			System.out.println("No pages to Go Back");
			
		}else {
		
			String page = s.pop();
			System.out.println("Back to previous page ");
		
		}
		
	}

	public void viewCurrentPage() {
		
		if(s.isEmpty()) {
			
			System.out.println("No pages to view");
			
		}
		else {
			
			System.out.println("Current page is "+s.peek());
			
		}
		
	}

	public void displayHistory() {
		
		if(s.isEmpty()) {
			
			System.out.println("Browsing histroy is clear");
			
		}
		else {
			
			System.out.println("---------Browsing History---------");
			for(String page : s) {
				
				System.out.println(page);
				
			}
			
		}
		
	}

	
	
}
