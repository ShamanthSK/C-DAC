package assign7;
import java.util.*;

public class ValidAgeMain {

	public static void main(String[] args) {
		
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter you age : ");
			int age = sc.nextInt();
			ExceptionAgeValidation.checkAge(age);
		
		}catch(InvalidAge e) {
			
			System.out.println(e.getMessage());
			
		}
		finally {
			
			System.out.println("Final statement is executed");
			
		}
	}
	
}
